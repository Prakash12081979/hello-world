﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharePointUserProfileUpdateJob
{
    [Serializable]
    public class ProfileUpdateException : Exception
    {
        public ProfileUpdateException()
        {

        }
        public ProfileUpdateException(string failedProfilePropertiesList)
            : base(String.Format("ProfileUpdateException: One or more property update failed for {0}.", failedProfilePropertiesList))
        {

        }
    }
}
