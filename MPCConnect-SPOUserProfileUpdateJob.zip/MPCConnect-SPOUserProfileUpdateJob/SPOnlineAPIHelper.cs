﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.SharePoint.Client;
using Microsoft.SharePoint.Client.UserProfiles;
using Microsoft.SharePoint.Client.Taxonomy;
using OfficeDevPnP.Core;
using System.Security.Cryptography.X509Certificates;

namespace SharePointUserProfileUpdateJob
{
    public class SPOnlineAPIHelper
    {
        private string TenantSPURL { get; set; }
        private string TenantSPAdminURL { get; set; }
        private string ApplicationID { get; set; }
        private string ApplicationSecret { get; set; }
        private ClientContext ClientCtx { get; set; }
        private PeopleManager PeopleMgr { get; set; }

        public SPOnlineAPIHelper(string SharePointURL,string SharePointAdminUrl,string AppId,string AppSecret)
        {
            this.TenantSPURL = SharePointURL;
            this.TenantSPAdminURL = SharePointAdminUrl;
            this.ApplicationID = AppId;
            this.ApplicationSecret = AppSecret;
            this.ClientCtx = new AuthenticationManager().GetAppOnlyAuthenticatedContext(this.TenantSPAdminURL, this.ApplicationID, this.ApplicationSecret);
            this.PeopleMgr = new PeopleManager(this.ClientCtx);
        }

        public void UpdateSharePointOnlineProfile(string userAccountName, Dictionary<string,string> properties, List<SPOUserProperty> userProfilePropertiesConfig, LogHelper logHelper)
        {            
            string UserAccountName = "i:0#.f|membership|"+userAccountName;
            bool partialProfileUpdateError = false;
            string failedProfilePropertiesList = "";

            foreach (string propName in properties.Keys)
            {
                //Identify if the property should be updated (By default, assume OverrideExistingValue=Yes)
                bool shouldUpdateProperty = true;
                
                //Get OverrideExistingValue definition for property from config
                SPOUserProperty propNameConfig = userProfilePropertiesConfig.Find(x => x.InternalName == propName);

                //If OverrideExistingValue=No for any property, verify if existing profile property value populated
                if (propNameConfig.OverrideExistingValue == "No")
                {
                    ClientResult<string> userProfilePropertyClientResult = PeopleMgr.GetUserProfilePropertyFor(UserAccountName, propName);
                    ClientCtx.ExecuteQuery();
                    string userProfilePropertyValue = userProfilePropertyClientResult.Value;

                    ///If profile property value is not empty, it will not be overridden, so set shouldUpdateProperty = false
                    if (!String.IsNullOrEmpty(userProfilePropertyValue))
                    {
                        shouldUpdateProperty = false;
                    }
                }

                // Update Profile Property
                if (shouldUpdateProperty)
                {
                    PeopleMgr.SetSingleValueProfileProperty(UserAccountName, propName, properties[propName]);
                    try
                    {
                        //Try to catch error while updating specific property
                        ClientCtx.ExecuteQuery();

                        //  Debug Section 1  //Temporary code to review detailed logging
                        //logHelper.WriteLogInformation(userAccountName, "Updated '" + propName + " with '" + properties[propName] + "'", String.Empty, LogHelper.LogCategory.SUCCESS, LogHelper.JobState.ProfileUpdate);
                        //  Debug Section 1  //
                    }
                    catch (Exception ex)
                    {
                        if (ex.Message.Contains("User Profile Error 1000"))
                        {
                            //Write in log that user does not exist, and break loop to move on to next user
                            throw;
                        }
                        else
                        {
                            partialProfileUpdateError = true;
                            //User exists, but error occurred while updating property
                            if (ex.Message.Contains("Invalid Term Value"))
                            {
                                logHelper.WriteLogInformation(userAccountName, "Cannot update '" + propName + "' with '" + properties[propName] + "'", "Term does not exist in associated Term Set.", LogHelper.LogCategory.ERROR, LogHelper.JobState.ProfileUpdate);
                            }
                            else
                            {
                                logHelper.WriteLogInformation(userAccountName, "Cannot update '" + propName + "' with '" + properties[propName] + "'", ex.Message, LogHelper.LogCategory.ERROR, LogHelper.JobState.ProfileUpdate);

                                //Try to update property with default value from configuration file
                                // -More Restrictive Option - if (propNameConfig.Type.ToUpper() == "MANAGED" && propNameConfig.DefaultValue != "")
                                if (propNameConfig.DefaultValue != "")
                                {
                                    PeopleMgr.SetSingleValueProfileProperty(UserAccountName, propName, propNameConfig.DefaultValue);
                                    try
                                    {
                                        //Try to catch error while updating specific property with default value
                                        ClientCtx.ExecuteQuery();
                                        logHelper.WriteLogInformation(userAccountName, "Updated '" + propName + "' with default value '" + propNameConfig.DefaultValue + "'", "", LogHelper.LogCategory.INFO, LogHelper.JobState.ProfileUpdate);
                                        partialProfileUpdateError = false;
                                    }
                                    catch (Exception ex1)
                                    {
                                        if (ex1.Message.Contains("Invalid Term Value"))
                                        {
                                            logHelper.WriteLogInformation(userAccountName, "Cannot update '" + propName + "' with default value '" + propNameConfig.DefaultValue + "'", "Term does not exist in associated Term Set.", LogHelper.LogCategory.ERROR, LogHelper.JobState.ProfileUpdate);
                                        }
                                        else
                                        {
                                            logHelper.WriteLogInformation(userAccountName, "Cannot update '" + propName + "' with default value '" + propNameConfig.DefaultValue + "'", ex.Message, LogHelper.LogCategory.ERROR, LogHelper.JobState.ProfileUpdate);
                                        }
                                    }
                                }
                            }
                            
                            if (String.IsNullOrEmpty(failedProfilePropertiesList))
                            {
                                string failedPropName = "'" + propName + "'";
                                failedProfilePropertiesList += failedPropName;
                            }
                            else
                            {
                                string failedPropName = ", '" + propName + "'";
                                failedProfilePropertiesList += failedPropName;
                            }
                        }
                    }
                }
                else
                {
                    logHelper.WriteLogInformation(userAccountName, "Ignoring '" + propName + "' for update", "Property is not defined to be overridden.", LogHelper.LogCategory.INFO, LogHelper.JobState.ProfileUpdate);
                }
            }
            //throw an exception if there was failure when updating one or more properties.
            if (partialProfileUpdateError)
            {
                throw new ProfileUpdateException(failedProfilePropertiesList);
            }
        }
        public bool DoesUPNExist(string userAccountName, LogHelper logHelper)
        {
            string UserAccountName = "i:0#.f|membership|" + userAccountName;
            ClientResult<string> userProfilePropertyClientResultUPN = PeopleMgr.GetUserProfilePropertyFor(UserAccountName, "AccountName");
            try
            {
                ClientCtx.ExecuteQuery();
            }
            catch (Exception ex)
            {
                logHelper.WriteLogInformation(userAccountName, "Error occurred when checking if user exists in tenant", ex.Message, LogHelper.LogCategory.ERROR, LogHelper.JobState.Gathering);
                return false;
            }
            string userProfilePropertyValueUPN = userProfilePropertyClientResultUPN.Value;
            if (String.IsNullOrEmpty(userProfilePropertyValueUPN))
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }
}
