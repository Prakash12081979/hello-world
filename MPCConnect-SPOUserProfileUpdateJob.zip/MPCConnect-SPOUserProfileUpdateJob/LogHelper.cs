﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace SharePointUserProfileUpdateJob
{
    public class LogHelper
    {
        private string LogFileFolder;
        private string LogFilePrefix;
        private string LogFileName;
        private string LogFilePath;
        public enum LogCategory
        {
            INFO,
            WARN,
            ERROR,
            SUCCESS
        }
        public enum JobState
        {
            Initialization,
            Gathering,
            ProfileUpdate,
            Completion
        }

        public LogHelper(string folderPath,string logFilePrefix)
        {
            try
            { 
                var directory = Directory.CreateDirectory(folderPath);            
                LogFileFolder = folderPath;
                LogFilePrefix = logFilePrefix;
                InitializeLogFile();
            }
            catch(Exception ex)
            {
                throw;
            }

        }

        void InitializeLogFile()
        {
            string currentDate = DateTime.Now.ToString("yyyy_MM_dd_hh_mm_ss");
            LogFileName = LogFilePrefix + "_" + currentDate + ".log";
            LogFilePath = LogFileFolder + "\\" + LogFileName;
            File.WriteAllText(LogFilePath, "LogDate\tCategory\tJob State\tUser UPN\tMessage\tExtended Message" + Environment.NewLine);

        }
        public void WriteLogInformation(string UPN, string message, string exMessage, LogCategory category, JobState jobState)
        {
            string logDate = DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss");
            string cat = category.ToString();
            string js = jobState.ToString();
            string UPNmsg = UPN;
            if (!String.IsNullOrEmpty(UPN))
            {
                UPNmsg = UPN + " - ";
            }
            switch (category)
            {
                case LogCategory.ERROR:
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(logDate + ":: ERROR::" + js + ":: " + UPNmsg + message + ". " + exMessage);
                    File.AppendAllText(LogFilePath, logDate + "\t" + cat + "\t" + js + "\t" + UPN + "\t" + message + ".\t" + exMessage + Environment.NewLine);
                    break;
                case LogCategory.WARN:
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine(logDate + ":: WARNING::" + js + ":: " + UPNmsg + message + ". " + exMessage);
                    File.AppendAllText(LogFilePath, logDate + "\t" + cat + "\t" + js + "\t" + UPN + "\t" + message + ".\t" + exMessage + Environment.NewLine);
                    break;
                case LogCategory.INFO:
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine(logDate + ":: INFO::" + js + ":: " + UPNmsg + message + ". " + exMessage);
                    File.AppendAllText(LogFilePath, logDate + "\t" + cat + "\t" + js + "\t" + UPN + "\t" + message + ".\t" + exMessage + Environment.NewLine);
                    break;
                case LogCategory.SUCCESS:
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine(logDate + ":: SUCCESS::" + js + ":: " + UPNmsg + message + ". " + exMessage);
                    File.AppendAllText(LogFilePath, logDate + "\t" + cat + "\t" + js + "\t" + UPN + "\t" + message + ".\t" + exMessage + Environment.NewLine);
                    break;
            }            
        }
    }
}
