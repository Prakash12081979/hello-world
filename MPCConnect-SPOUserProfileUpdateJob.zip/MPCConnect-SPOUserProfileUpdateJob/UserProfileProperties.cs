﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharePointUserProfileUpdateJob
{
    class UserProfileProperties
    {
        public string UserPrincipalName { get; set; }
        public string PIC { get; set; }
        public string EmployeeType { get; set; }
        public string AssignedLocations { get; set; }
        public string PhysicalLocation { get; set; }
        public string SAPUID { get; set; }
        public string EmployeeNumber { get; set; }
        public string Company { get; set; }
        public string Address1 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string ZipCode { get; set; }
        public string SAPCostCenter { get; set; }
        public string IsUpdatedByCustomProfileJob { get; set;}
    }


}
