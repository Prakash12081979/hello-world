﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace SharePointUserProfileUpdateJob
{
   
     
    class Program
    {     

        static int Main(string[] args)
        {
            string configFileLocation = args[0];
            //string configFileLocation = "C:\\Users\\skk\\source\\repos\\MPCConnect-SPOUserProfileUpdateJob\\SPUpdateConfig - MTESTNET.json";
            //string configFileLocation = "C:\\Users\\skk\\source\\repos\\MPCConnect-SPOUserProfileUpdateJob\\SPUpdateConfig.json";
            SPProfileUpdateJob spJob = new SPProfileUpdateJob();
            bool jobStatus = spJob.MainProcess(configFileLocation);
            if (jobStatus)
                return 1;
            else
                return 0;
        }
    }
   
}
