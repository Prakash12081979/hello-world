﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.DirectoryServices;

namespace SharePointUserProfileUpdateJob
{
    class ActiveDirectoryHelper : IDisposable
    {
        readonly DirectoryEntry dirEntry;
        

        public ActiveDirectoryHelper(string domain)
        {
            this.dirEntry = new DirectoryEntry("LDAP://" + domain);            
        }
        public void Dispose()
        {
            this.dirEntry.Dispose();
        }

        public string GetUPNFromsAM(string sAMAccountName)
        {
            string userPrincipalName = string.Empty;
            DirectorySearcher Dsearch = new DirectorySearcher(this.dirEntry)
            {
                Filter = "(&(objectClass=user)(sAMAccountName=" + sAMAccountName + "))"
            };
            foreach (SearchResult sResult in Dsearch.FindAll())
            {
                if (sResult.Properties.Contains("userPrincipalName"))
                {
                    userPrincipalName = sResult.Properties["userPrincipalName"][0].ToString();
                }
            }
            Dsearch.Dispose();
            return userPrincipalName;

        }
        public Dictionary<string,string> GetUPNForAllUsers()
        {
            Dictionary<string, string> allUsers = new Dictionary<string, string>();
            DirectorySearcher Dsearch = new DirectorySearcher(this.dirEntry)
            {
                Filter = "(&(objectCategory=user)(objectClass=user))",
                PageSize = 10000,
                ClientTimeout = TimeSpan.FromHours(1)
            };
            SearchResultCollection searchResults = Dsearch.FindAll();
            foreach (SearchResult sResult in searchResults)
            {
                if (sResult.Properties.Contains("userPrincipalName"))
                {
                    string userPrincipalName = sResult.Properties["userPrincipalName"][0].ToString();
                    string samAccountName = sResult.Properties["sAMAccountName"][0].ToString();
                    if (!string.IsNullOrEmpty(userPrincipalName) && !allUsers.ContainsKey(samAccountName))
                    {
                        allUsers.Add(samAccountName.ToUpper(), userPrincipalName);
                    }
                }
            }
            Dsearch.Dispose();
            return allUsers;
        }
    }
}
