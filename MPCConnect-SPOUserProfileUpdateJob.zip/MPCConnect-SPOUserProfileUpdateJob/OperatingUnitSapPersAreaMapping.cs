﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharePointUserProfileUpdateJob
{
    public class OperatingUnitSapPersAreaMapping
    {
        public string SapPersArea { get; set; }
        public string SapPersAreaDesc { get; set; }
        public string OperatingUnitGroup { get; set; }
        public string OperatingUnitName { get; set; }
    }
}
