﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace SharePointUserProfileUpdateJob
{
    public class Config
    {
        public string PrimaryDomain { get; set; }
        public string SecondaryDomain { get; set; }
        public string LogFileFolder { get; set; }
        public string LogFilePrefix { get; set; }
        public string SPOnlineUrl { get; set; }
        public string SPOnlineAdminUrl { get; set; }
        public string ApplicationID { get; set; }
        public string ApplicationSecret { get; set; }
        public string IAMServerName { get; set; }
        public string IAMDBName { get; set; }
        public string IAMQuery { get; set; }
        public int IAMQueryTimeout { get; set; }
        public string SAPHRGoldServerName { get; set; }
        public string SAPHRGoldDBName { get; set; }
        public string SAPHRGoldQuery { get; set; }
        public int SAPHRGoldQueryTimeout { get; set; }        
        public string OperatingUnitsKeyInIAM { get; set; }
        public OperatingUnitSapPersAreaMapping[] OperatingUnitsMapping { get; set; }
        public List<SPOUserProperty> UserProperties { get; set; }
        private string ConfigFileLocation { get; set; }
        

        
        public Config(string fileLocation)
        {
            ConfigFileLocation = fileLocation;
        }
        public Config()
        {

        }

        public void GetConfiguration()
        {
            try
            {
                string jsonString = System.IO.File.ReadAllText(ConfigFileLocation);
                Config tempObj = JsonSerializer.Deserialize<Config>(jsonString);
                this.IAMServerName = tempObj.IAMServerName;
                this.IAMDBName = tempObj.IAMDBName;
                this.IAMQuery = tempObj.IAMQuery;
                this.IAMQueryTimeout = tempObj.IAMQueryTimeout;

                this.SAPHRGoldServerName = tempObj.SAPHRGoldServerName;
                this.SAPHRGoldDBName = tempObj.SAPHRGoldDBName;
                this.SAPHRGoldQuery = tempObj.SAPHRGoldQuery;
                this.SAPHRGoldQueryTimeout = tempObj.SAPHRGoldQueryTimeout;
                this.OperatingUnitsKeyInIAM = tempObj.OperatingUnitsKeyInIAM;
                this.OperatingUnitsMapping = tempObj.OperatingUnitsMapping;
                this.SPOnlineUrl = tempObj.SPOnlineUrl;
                this.SPOnlineAdminUrl = tempObj.SPOnlineAdminUrl;
                this.ApplicationID = tempObj.ApplicationID;
                this.ApplicationSecret = tempObj.ApplicationSecret;
              
                this.UserProperties = tempObj.UserProperties;
                this.LogFileFolder = tempObj.LogFileFolder;
                this.LogFilePrefix = tempObj.LogFilePrefix;
                this.PrimaryDomain = tempObj.PrimaryDomain;
                this.SecondaryDomain = tempObj.SecondaryDomain;
                
                tempObj = null;
                

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadLine();

            }

        }
    }
    
    

    

   
}
