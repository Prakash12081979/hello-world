﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Data.SqlClient;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;

namespace SharePointUserProfileUpdateJob
{
    public class SPProfileUpdateJob
    {
        private Config currentConfig;
        private Dictionary<string, UserProfileProperties> IAMUsersList = new Dictionary<string, UserProfileProperties>();
        private List<SPOUserProperty> userProfileProperties;
        private Dictionary<string, OperatingUnitSapPersAreaMapping> OperatingUnitMappings = new Dictionary<string, OperatingUnitSapPersAreaMapping>();
        SPOnlineAPIHelper spoHelper;
        LogHelper logHelper;
        Dictionary<string, string> AllMainDomainUsers;
        Dictionary<string, string> AllAltDomainVUsers;
        string PrimaryDomain;
        string SecondaryDomain;
        bool processSecondaryDomain;
        int successCount = 0;
        int errorCount = 0;

        enum DomainType
        {
            PRIMARY,
            SECONDARY
        }

        public bool MainProcess(string ConfigfileLocation)
        {
            try
            {
                DateTime startDate = DateTime.Now;
                currentConfig = new Config(ConfigfileLocation);
                currentConfig.GetConfiguration();
                logHelper = new LogHelper(currentConfig.LogFileFolder, currentConfig.LogFilePrefix);
                logHelper.WriteLogInformation(String.Empty, "Retrieved Configuration...", String.Empty, LogHelper.LogCategory.INFO, LogHelper.JobState.Initialization);
                spoHelper = new SPOnlineAPIHelper(currentConfig.SPOnlineUrl, currentConfig.SPOnlineAdminUrl, currentConfig.ApplicationID, currentConfig.ApplicationSecret);
                userProfileProperties = currentConfig.UserProperties;
                PrimaryDomain = currentConfig.PrimaryDomain;
                if (currentConfig.SecondaryDomain == "")
                {
                    this.processSecondaryDomain = false;
                }
                else
                {
                    this.processSecondaryDomain = true;
                    SecondaryDomain = currentConfig.SecondaryDomain;
                }

                //Store Operating Units Mappings in dictionary with SapPersArea as key
                foreach (OperatingUnitSapPersAreaMapping opu in currentConfig.OperatingUnitsMapping)
                {
                    OperatingUnitMappings.Add(opu.SapPersArea, opu);
                }

                logHelper.WriteLogInformation(String.Empty, "Retrieving all primary domain:" + PrimaryDomain + " user accounts.", String.Empty, LogHelper.LogCategory.INFO, LogHelper.JobState.Initialization);
                GetDomainUserAccounts(PrimaryDomain, DomainType.PRIMARY);
                logHelper.WriteLogInformation(String.Empty, "Retrieved " + AllMainDomainUsers.Count.ToString() + " user accounts...", String.Empty, LogHelper.LogCategory.INFO, LogHelper.JobState.Initialization);

                if (this.processSecondaryDomain)
                {
                    logHelper.WriteLogInformation(String.Empty, "Retrieving all secondary domain:" + SecondaryDomain + " user accounts.", String.Empty, LogHelper.LogCategory.INFO, LogHelper.JobState.Initialization);
                    GetDomainUserAccounts(SecondaryDomain, DomainType.SECONDARY);
                    logHelper.WriteLogInformation(String.Empty, "Retrieved " + AllAltDomainVUsers.Count.ToString() + " user accounts...", String.Empty, LogHelper.LogCategory.INFO, LogHelper.JobState.Initialization);
                }

                logHelper.WriteLogInformation(String.Empty, "Querying IAM Gold tables and Active Directory for user details.", String.Empty, LogHelper.LogCategory.INFO, LogHelper.JobState.Gathering);
                GetIAMUserList(currentConfig.IAMServerName, currentConfig.IAMDBName, currentConfig.IAMQuery, currentConfig.IAMQueryTimeout);
                logHelper.WriteLogInformation(String.Empty, "Query completed...", String.Empty, LogHelper.LogCategory.INFO, LogHelper.JobState.Gathering);

                logHelper.WriteLogInformation(String.Empty, "Proceeding with User Profile Updates...", String.Empty, LogHelper.LogCategory.INFO, LogHelper.JobState.ProfileUpdate);
                foreach (string IAMUserUPN in IAMUsersList.Keys)
                {
                    try
                    {

                        bool success = UpdateSPOUserProfile(IAMUserUPN);
                        if (success)
                        {
                            successCount++;
                        }
                        else
                        {
                            errorCount++;
                        }
                    }
                    catch (Exception ex)
                    {
                        logHelper.WriteLogInformation(IAMUserUPN, "User Profile could not be updated. Unexpected error occurred", ex.Message, LogHelper.LogCategory.ERROR, LogHelper.JobState.ProfileUpdate);
                        errorCount++;
                    }
                }

                logHelper.WriteLogInformation(String.Empty, "User Profile Updates completed...", String.Empty, LogHelper.LogCategory.INFO, LogHelper.JobState.Completion);
                logHelper.WriteLogInformation(String.Empty, "Total profiles updated: " + successCount + ", profiles failed: " + errorCount, String.Empty, LogHelper.LogCategory.INFO, LogHelper.JobState.Completion);

                if (errorCount == 0)
                {
                    logHelper.WriteLogInformation(String.Empty, "User Profile Update Job completed successfully...", String.Empty, LogHelper.LogCategory.SUCCESS, LogHelper.JobState.Completion);
                }
                else
                {
                    logHelper.WriteLogInformation(String.Empty, "User Profile Update Job completed successfully with errors...", String.Empty, LogHelper.LogCategory.WARN, LogHelper.JobState.Completion);
                }
                logHelper.WriteLogInformation(String.Empty, "Total Execution Time: " + DateTime.Now.Subtract(startDate), String.Empty, LogHelper.LogCategory.INFO, LogHelper.JobState.Completion);

                return true;
            }
            catch (Exception ex)
            {
                logHelper.WriteLogInformation(String.Empty, "Unexpected error occurred", ex.Message, LogHelper.LogCategory.ERROR, LogHelper.JobState.Completion);
                logHelper.WriteLogInformation(String.Empty, "User Profile Update Job Failed...", String.Empty, LogHelper.LogCategory.ERROR, LogHelper.JobState.Completion);
                return false;
            }   
        }

        private void GetDomainUserAccounts(string domain, DomainType domainType)
        {
            ActiveDirectoryHelper ADObj = new ActiveDirectoryHelper(domain);
            switch (domainType)
            {
                case DomainType.PRIMARY:
                    AllMainDomainUsers = ADObj.GetUPNForAllUsers();
                    break;
                case DomainType.SECONDARY:
                    AllAltDomainVUsers = ADObj.GetUPNForAllUsers();
                    break;
            }

            ADObj.Dispose();
        }
       
        /// <summary>
        /// This function queries IAM tables, gets a list of all users, assigns business unis and user principal names
        /// </summary>
        /// <param name="serverInstance"></param>
        /// <param name="databaseName"></param>
        /// <param name="query"></param>
        /// <param name="queryTimeout"></param>
        void GetIAMUserList(string serverInstance, string databaseName, string query, int queryTimeout)
        {
            string sqlConnString = "Data Source=" + serverInstance + ";Initial Catalog=" + databaseName + ";" + "Integrated Security=true;";
            using (SqlConnection sqlConn = new SqlConnection(sqlConnString))
            {
                string altUserID = string.Empty;
                SqlCommand sqlcmd = new SqlCommand(query, sqlConn)
                {
                    CommandTimeout = queryTimeout
                };
                sqlConn.Open();
                using (SqlDataReader sqlReader = sqlcmd.ExecuteReader())
                {
                    while (sqlReader.Read())
                    {
                        UserProfileProperties IAMUser = new UserProfileProperties();
                        UserProfileProperties IAMUserAlt = new UserProfileProperties();

                        foreach (SPOUserProperty prop in userProfileProperties)
                        {
                            PropertyInfo propertyInfo = IAMUser.GetType().GetProperty(prop.InternalName);
                            PropertyInfo propertyInfoAlt = IAMUserAlt.GetType().GetProperty(prop.InternalName);
                            //Add values for IAM User as those are in IAM Table
                            if (prop.Source == "IAM")
                            {
                                propertyInfo.SetValue(IAMUser, Convert.ChangeType(sqlReader[prop.InternalName], propertyInfo.PropertyType), null);
                                propertyInfoAlt.SetValue(IAMUserAlt, Convert.ChangeType(sqlReader[prop.InternalName], propertyInfoAlt.PropertyType), null);
                            }
                            
                        }

                        //Define IsUpdatedByCustomProfJob to be 'true' since the profile will be updated by this job.
                        IAMUser.IsUpdatedByCustomProfileJob = "true";
                        IAMUserAlt.IsUpdatedByCustomProfileJob = "true";

                        //Add Operating Unit for IAM User 
                        if (OperatingUnitMappings.ContainsKey(sqlReader[currentConfig.OperatingUnitsKeyInIAM].ToString()))
                        {
                            IAMUser.AssignedLocations = OperatingUnitMappings[sqlReader[currentConfig.OperatingUnitsKeyInIAM].ToString()].OperatingUnitName;
                            IAMUserAlt.AssignedLocations = OperatingUnitMappings[sqlReader[currentConfig.OperatingUnitsKeyInIAM].ToString()].OperatingUnitName;
                        }

                        //Get AltUserId value for IAM User
                        altUserID = sqlReader["AltUserId"].ToString();

                        if (AllMainDomainUsers.ContainsKey(IAMUser.PIC.ToString()))
                        {
                            IAMUser.UserPrincipalName = AllMainDomainUsers[IAMUser.PIC.ToUpper()];
                            if (!string.IsNullOrEmpty(IAMUser.UserPrincipalName) && !IAMUsersList.ContainsKey(IAMUser.UserPrincipalName))
                            {
                                if (spoHelper.DoesUPNExist(IAMUser.UserPrincipalName, logHelper))
                                {
                                    IAMUsersList.Add(IAMUser.UserPrincipalName, IAMUser);
                                }
                                else
                                {
                                    logHelper.WriteLogInformation(IAMUser.UserPrincipalName, "SharePoint Profile for user does not exist in Tenant", String.Empty, LogHelper.LogCategory.WARN, LogHelper.JobState.Gathering);
                                }
                            }
                            else
                            {
                                //Write Error User Already Exists
                                logHelper.WriteLogInformation(IAMUser.UserPrincipalName, "Duplicated UPN found for User ID/PIC '" + IAMUser.PIC.ToString() + "'. It will be ignored", String.Empty, LogHelper.LogCategory.WARN, LogHelper.JobState.Gathering);
                            }
                        }
                        
                        if (this.processSecondaryDomain)
                        {
                            if (!string.IsNullOrEmpty(altUserID))
                            {
                                if (AllAltDomainVUsers.ContainsKey(altUserID))
                                {
                                    IAMUserAlt.UserPrincipalName = AllAltDomainVUsers[altUserID];
                                    if (!string.IsNullOrEmpty(IAMUserAlt.UserPrincipalName) && !IAMUsersList.ContainsKey(IAMUserAlt.UserPrincipalName))
                                    {
                                        if (spoHelper.DoesUPNExist(IAMUserAlt.UserPrincipalName, logHelper))
                                        {
                                            IAMUsersList.Add(IAMUserAlt.UserPrincipalName, IAMUserAlt);
                                        }
                                        else
                                        {
                                            logHelper.WriteLogInformation(IAMUserAlt.UserPrincipalName, "SharePoint Profile for user does not exist in Tenant", String.Empty, LogHelper.LogCategory.WARN, LogHelper.JobState.Gathering);
                                        }
                                    }
                                    else
                                    {
                                        //Write Error User Already Exists
                                        logHelper.WriteLogInformation(IAMUser.UserPrincipalName, "Duplicated UPN found for User ID/PIC '" + altUserID + "'. It will be ignored", String.Empty, LogHelper.LogCategory.WARN, LogHelper.JobState.Gathering);
                                    }
                                }
                            }
                        }


                    }
                }
            }

        }
        
        bool UpdateSPOUserProfile(string UserPrincipalName)
        {            
            Dictionary<string, string> properties = new Dictionary<string, string>();

            foreach (SPOUserProperty prop in userProfileProperties)
            {
                PropertyInfo propertyInfo = IAMUsersList[UserPrincipalName].GetType().GetProperty(prop.InternalName);
                try
                {
                    //This Try block will catch exception if any property value is NULL
                    string propValue = propertyInfo.GetValue(IAMUsersList[UserPrincipalName]).ToString();

                    properties.Add(prop.InternalName, propValue);
                }
                catch (Exception ex)
                {
                    if (ex.Message.Contains("Object reference not set to an instance of an object"))
                    {
                        logHelper.WriteLogInformation(UserPrincipalName, "'" + prop.InternalName + "' for user does not have value defined at user data source or associated mapping in Config file", ex.Message, LogHelper.LogCategory.ERROR, LogHelper.JobState.ProfileUpdate);
                    }
                    else
                    {
                        logHelper.WriteLogInformation(UserPrincipalName, "Error occurred while retrieving '" + prop.InternalName + "' for user", ex.Message, LogHelper.LogCategory.ERROR, LogHelper.JobState.ProfileUpdate);
                    }
                }                    
            }

            try
            {
                spoHelper.UpdateSharePointOnlineProfile(UserPrincipalName, properties, userProfileProperties, logHelper);
                logHelper.WriteLogInformation(UserPrincipalName, "User Profile updated successfully", String.Empty, LogHelper.LogCategory.SUCCESS, LogHelper.JobState.ProfileUpdate);
                return true;
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("User Profile Error 1000"))
                {
                    //Write in log that user does not exist, and break to move on to next user
                    logHelper.WriteLogInformation(UserPrincipalName, "User Profile could not be updated. SharePoint Profile for user is no longer found in Tenant", ex.Message, LogHelper.LogCategory.ERROR, LogHelper.JobState.ProfileUpdate);
                    return false;
                }
                else if (ex.Message.Contains("ProfileUpdateException"))
                {
                    logHelper.WriteLogInformation(UserPrincipalName, "User Profile could not be updated completely", ex.Message, LogHelper.LogCategory.ERROR, LogHelper.JobState.ProfileUpdate);
                    return false;
                }
                else
                {
                    logHelper.WriteLogInformation(UserPrincipalName, "User Profile could not be updated. Unexpected error occurred while updating profile for user", ex.Message, LogHelper.LogCategory.ERROR, LogHelper.JobState.ProfileUpdate);
                    return false;
                }
            }
        }
    }
}
